#include "./juce_patched_gui_basics.cpp"
