#if JUCE_MODULE_AVAILABLE_juce_gui_basics
#include "./juce_patched_gui_basics.cpp"
#endif